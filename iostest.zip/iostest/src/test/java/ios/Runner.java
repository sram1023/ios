package ios;

import io.appium.java_client.ios.IOSDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;

public class Runner {
    public static void main(String[] args) throws MalformedURLException {

        firstTest();

    }

    public static void firstTest() throws MalformedURLException {


        DesiredCapabilities cap = new DesiredCapabilities();

        cap.setCapability("platformName", "iOS");
        cap.setCapability("platformVersion", "15.5");
        cap.setCapability("deviceName", "iPhone 13");
        //cap.setCapability(CapabilityType.BROWSER_NAME, "safari");
        cap.setCapability("app", "/Users/arun.thiagarajan/Downloads/SignInApp/build/Release-iphonesimulator/SignInApp.app");

        URL url = new URL("http://127.0.0.1:4723/wd/hub");

        IOSDriver driver = new IOSDriver(url, cap);
    }
}
