package pages;

import org.openqa.selenium.WebElement;
import net.serenitybdd.core.annotations.findby.By;

public class logIn extends  AbstractPage{

    public WebElement emailaddress()
    {
        return waitForUnstableElement(By.id("email"));
    }

    public WebElement password()
    {
        return waitForUnstableElement(By.id("passwd"));
    }

    public WebElement signButton()
    {
        return waitForUnstableElement(By.id("SubmitLogin"));
    }
}
