package stepdefinitions;

import com.demo.base.Context;
import commonutil.Util;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Tfl extends Context {

    Util util;

    public Tfl() {
        util = new Util();
    }

    @Given("^a TFL user lands of application$")
    public void logIn(){
        log.info("User has landed on TFL application");
    }

    @And("^user enters (.+) and (.+) to signIn$")
    public void userRightCredentials(String userName,String password){
        util.signIn(userName,password);
    }

    @Then("^user validates (.+) (.+) and (.+) in homepage$")
    public void userValidation(String name, String role,String office){
        util.userValidation(name,role,office);
    }

    @And("^user enters invalid (.+) and (.+) to signIn$")
    public void userWrongCredentials(String userName,String password){
        util.signIn(userName,password);
    }

    @And("^user signOut the application$")
    public void userSignOut(){
        util.signOut();
    }

    @And("^user navigate to login screen$")
    public void userNavigate(String userName,String password){
        util.signIn(userName,password);
    }


    @Then("^user validates the (.+) text in the popup$")
    public void userLoginErrorValidation(String errorText){
        util.userErrorLogin(errorText);
    }
}
