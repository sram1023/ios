# TestNG
This test would be running in Zalenium and pre-requisite is Docker should be installed into the machine.
